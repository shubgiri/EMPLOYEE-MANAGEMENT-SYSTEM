from django.shortcuts import render, redirect
from . forms import Employee_model
from . forms import Employee_form


def savedemo(request):
    if request.method == "POST":
        form = Employee_form(request.POST)
        if form.is_valid():
            form.save()
            return redirect("/")
    else:
        form = Employee_form()

    return render(request, 'showform.html', {'form': form})


def displaydata(request):
    data = Employee_model.objects.all()
    return render(request, 'display.html', {'res': data})


def edit(request, id):
    data = Employee_model.objects.get(id = id)
    return render(request, 'edit.html', {'res': data})


def updatedata(request, id):
    emp = Employee_model.objects.get(id = id)
    data = Employee_form(request.POST, instance=emp)
    if data.is_valid():
        data.save()
        return redirect("/display")


def deletedata(request, id):
    data = Employee_model.objects.get(id = id)
    data.delete()
    return redirect("/display")
